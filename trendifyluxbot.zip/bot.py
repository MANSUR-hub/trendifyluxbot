# Trendify Lux Bot code

print('Bot is running')